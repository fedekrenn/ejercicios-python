from setuptools import setup

setup(
    name='modulos-paquetes-package',
    version='1.0',
    description='Ejemplo de paquete con un módulo',
    author='Krenn, Federico Nicolás',
    author_email='fedekrenn@gmail.com',
    packages=['client_package']
)
